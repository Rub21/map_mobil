$('.details-page').live("pageshow", function() {
    var f = new Date();
    map = L.mapbox.map('map').setView([-12.047816, -77.062203],
        14);
    L.mapbox.tileLayer('armandoperu.hh42cm09', {
        attribution: 'Powered by <a target="_blank" href="http://geosolution.pe/">Geosolution ' + f.getFullYear() + '</a>'
    }).addTo(map);

    $.getJSON('https://dl.dropboxusercontent.com/u/43116811/ruben/files_geosolu/Norte.geojson', {
        format: "json"
    }).done(function(data) {
        console.log(data);
        map.markerLayer.setGeoJSON(data);

    });


});


function locatedme() {
    map.on('locationfound', function(e) {
        map.fitBounds(e.bounds);

        map.featureLayer.setGeoJSON({
            type: "Feature",
            geometry: {
                type: "Point",
                coordinates: [e.latlng.lng, e.latlng.lat]
            },
            properties: {
                'marker-color': '#000',
                'marker-symbol': 'star-stroked'
            }
        });

        // And hide the geolocation button
        geolocate.parentNode.removeChild(geolocate);
    });

};



function popup() {
    alert('hola');
    $('element_to_pop_up').bPopup({
        easing: 'easeOutBack', //uses jQuery easing plugin
        speed: 450,
        transition: 'slideDown'
    });
    alert('chau');
}

function onNorte() {
    var position = L.latLng(-11.781168, -77.15816);
    map.panTo(position);
}

function onSur() {
    var position = L.latLng(-12.02480, -77.05871);
    map.panTo(position);
}

function onEste() {
    var position = L.latLng(-12.057613, -76.971211);
    map.panTo(position);
}